# Task Risk Gate

## Kurz-Check vor Umsetzung
- Ziel klar? (ja/nein)
- Externe Integrationen? (welche)
- Datenzugriff nötig? (welcher Scope)
- Kann der Task irreversible Side-Effects haben? (ja/nein)
- Braucht es Human Approval? (ja/nein)

## Risk Level
- Low: keine sensiblen Daten, reversible
- Medium: externe APIs, begrenzter Datenzugriff
- High: Zahlungsdaten, Credentials, destructive actions

## Gate-Regel
- Low → direkt umsetzen
- Medium → umsetzen + Logging verpflichtend
- High → vor Umsetzung Human/CEO Freigabe
