# HEARTBEAT — Security & Ops

## Täglich (5-10 Min)
1. Prüfe fehlgeschlagene Jobs / Cron-Runs der letzten 24h
2. Prüfe neue/ungeplante Tool-Nutzung (exec, browser, message)
3. Prüfe offene TODOs mit Security- oder Access-Bezug
4. Prüfe Secrets-Status: irgendwo Token/Keys in Klartext gelandet?
5. Logge 1-3 Zeilen in `memory/security-log.md`

## Wenn Alert gefunden
- Severity setzen: low / medium / high
- Incident in `incident-log` anlegen
- Owner + nächster Schritt + ETA definieren
