# Secret Handling Policy (MVP)

## Grundregeln
1. Keine Tokens/API Keys in Wiki, Slack, Commits, Screenshots
2. Secrets nur über sichere Config/ENV-Mechanismen
3. Least Privilege: minimal nötige Scopes
4. Rotation bei Leak-Verdacht sofort

## Red Flags
- Token im Klartext in Chat-Verläufen
- "quick fix" mit hardcoded credential
- Unbekannte Tools mit Vollzugriff

## Leak Response (Sofort)
1. Secret invalidieren/rotieren
2. betroffene Integrationen prüfen
3. Incident loggen
4. Post-Mortem mit Präventionsmaßnahme
