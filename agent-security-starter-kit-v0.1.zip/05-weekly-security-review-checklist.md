# Weekly Security Review

- [ ] Alle neuen Integrationen auf Scope geprüft
- [ ] Secrets-Rotation bei kritischen Diensten geprüft
- [ ] Incident-Log reviewed und offene Punkte priorisiert
- [ ] Risk-Gate bei allen High-Risk Tasks angewandt
- [ ] 1 Verbesserung fürs nächste Woche-Sicherheitsniveau definiert
