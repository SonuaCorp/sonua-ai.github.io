# Incident Log

## Incident
- ID:
- Datum/Zeit:
- Entdeckt durch:
- Severity: low / medium / high
- Status: open / mitigated / closed

## Was ist passiert?
(Kurzbeschreibung)

## Impact
- Betroffene Systeme:
- Potenzieller Schaden:

## Maßnahmen
- Sofortmaßnahmen:
- Dauerhafte Fixes:
- Owner:
- Deadline:

## Learnings
- Root Cause:
- Wie verhindern wir Wiederholung?
